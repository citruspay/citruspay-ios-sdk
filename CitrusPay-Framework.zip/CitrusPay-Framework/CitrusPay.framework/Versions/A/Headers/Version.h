//
//  Version.h
//  CTS iOS Sdk
//
//  Created by Yadnesh Wankhede on 28/05/15.
//  Copyright (c) 2015 Citrus. All rights reserved.
//

#ifndef CTS_iOS_Sdk_Version_h
#define CTS_iOS_Sdk_Version_h
#define SDK_VERSION @"3.1.3"
#endif
