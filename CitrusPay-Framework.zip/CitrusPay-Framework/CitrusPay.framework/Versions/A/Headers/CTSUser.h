//
//  CTSUser.h
//  CTS iOS Sdk
//
//  Created by Yadnesh on 9/1/15.
//  Copyright (c) 2015 Citrus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CTSUser : NSObject
@property(strong) NSString *email,*mobile;
@end
