//
//  CitrusCashRes.h
//  CTS iOS Sdk
//
//  Created by Yadnesh Wankhede on 19/02/15.
//  Copyright (c) 2015 Citrus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CTSCitrusCashRes : NSObject
@property(strong)NSMutableDictionary *responseDict;
@end
